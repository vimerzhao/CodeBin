package com.vimerzhao.mediaplayer.music.model;


import android.os.Parcel;
import android.os.Parcelable;

public class MusicBean implements Parcelable {
    private String name;
    private String singer;
    private String path;
    private int duration;
    private long size;

    public MusicBean() {}

    protected MusicBean(Parcel in) {
        name = in.readString();
        singer = in.readString();
        path = in.readString();
        duration = in.readInt();
        size = in.readLong();
    }

    public static final Creator<MusicBean> CREATOR = new Creator<MusicBean>() {
        @Override
        public MusicBean createFromParcel(Parcel in) {
            return new MusicBean(in);
        }

        @Override
        public MusicBean[] newArray(int size) {
            return new MusicBean[size];
        }
    };

    @Override
    public String toString() {
        return name + singer + path + duration +  '-' + size;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public String getSinger() {
        return singer;
    }

    public String getPath() {
        return path;
    }

    public int getDuration() {
        return duration;
    }

    public long getSize() {
        return size;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(singer);
        dest.writeString(path);
        dest.writeInt(duration);
        dest.writeLong(size);
    }
}
