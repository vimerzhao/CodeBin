package com.vimerzhao.mediaplayer.music.presenter;


import android.content.Context;
import android.media.audiofx.Visualizer;
import android.os.Handler;
import android.os.IBinder;

import com.vimerzhao.mediaplayer.common.view.VisualizerView;
import com.vimerzhao.mediaplayer.music.model.MusicBean;
import com.vimerzhao.mediaplayer.music.service.MusicPlayService;
import com.vimerzhao.mediaplayer.music.view.MusicListFragment;
import com.vimerzhao.mediaplayer.music.view.PlayActivity;

import java.util.ArrayList;
import java.util.List;

public interface IPlayPresenter {
    // for model layer
    List<MusicBean> getLocalMusicList(Context context);
    List<MusicBean> getOnlineMusicList(String keyWords);

    // for view layer
    MusicPlayService prepareService(MusicPlayService playService, IBinder service, ArrayList<MusicBean> playList, int index);
    Visualizer prepareVisualizer(Visualizer visualizer, final VisualizerView view, MusicPlayService service);
    void changeLoopMode(MusicPlayService service, PlayActivity activity);
    void playOrPause(MusicPlayService service, PlayActivity activity, Handler handler, Runnable seekBarThread);
    void showLocalMusicList(MusicListFragment fragment);
    void showOnlineMusicList(MusicListFragment fragment);
}
