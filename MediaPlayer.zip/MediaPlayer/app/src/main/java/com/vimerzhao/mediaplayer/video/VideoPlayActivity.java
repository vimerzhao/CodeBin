package com.vimerzhao.mediaplayer.video;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.VideoView;


import com.vimerzhao.mediaplayer.R;

import java.util.ArrayList;


public class VideoPlayActivity extends AppCompatActivity {
    private VideoView mVideoView;
    private ArrayList<VideoBean> mPlayList;
    private int mCurIndex;
    private int mCurMode;//Single,Loop,random
    private ImageButton mLoopModeBtn;
    private ImageButton mPreviousBtn;
    private ImageButton mPlayPauseBtn;
    private ImageButton mNextBtn;
    private ImageButton mVideoListBtn;
    public final static int LOOP_MODE = 0;
    public final static int SINGLE_MODE = 1;
    public final static int RANDOM_MODE = 2;
    private final static int MODE_COUNT = 3;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play);
        if (Build.VERSION.SDK_INT >= 21) {
            ActionBar supportActionBar = getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.setElevation(0);
            }
        }

        initViews();
        mCurMode = LOOP_MODE;
        Bundle bundle = this.getIntent().getExtras();
        mPlayList = bundle.getParcelableArrayList(VideoListFragment.VIDEO_LIST);
        mCurIndex = bundle.getInt(VideoListFragment.CUR_VIDEO);
        play();
        mPlayPauseBtn.setImageResource(R.mipmap.btn_media_pause);

    }
    private void play() {
        mVideoView.requestFocus();
        mVideoView.setVideoURI(Uri.parse(mPlayList.get(mCurIndex).getPath()));
        mVideoView.start();
    }
    private void initViews() {
        mLoopModeBtn = findViewById(R.id.btn_loop_mode);
        mLoopModeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateCurMode();

            }
        });
        mPreviousBtn = findViewById(R.id.btn_previous_music);
        mPreviousBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateIndex(-1);
                play();
            }
        });
        mPlayPauseBtn = findViewById(R.id.btn_play_pause);
        mPlayPauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mVideoView.isPlaying()) {
                    mPlayPauseBtn.setImageResource(R.mipmap.btn_media_play);
                    mVideoView.pause();
                } else {
                    mPlayPauseBtn.setImageResource(R.mipmap.btn_media_pause);
                    mVideoView.start();
                }
            }
        });
        mNextBtn = findViewById(R.id.btn_next_music);
        mNextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateIndex(1);
                play();
            }
        });
        mVideoListBtn = findViewById(R.id.btn_music_list);
        mVideoView = findViewById(R.id.vv_video_play);
        mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
            }
        });
    }
    private void updateIndex(int change) {
        switch (mCurMode) {
            case LOOP_MODE:
                mCurIndex = (mCurIndex + change + mPlayList.size()) % mPlayList.size();
                break;
            case RANDOM_MODE:
                mCurIndex = (int) (Math.random() * mPlayList.size());
                System.out.println(mCurIndex);
                break;
            case SINGLE_MODE:
                break;
        }

    }

    public void updateCurMode() {
        mCurMode = (mCurMode + 1) % MODE_COUNT;
    }
}
