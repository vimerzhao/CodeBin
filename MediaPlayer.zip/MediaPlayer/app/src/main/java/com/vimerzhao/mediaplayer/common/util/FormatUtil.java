package com.vimerzhao.mediaplayer.common.util;


public class FormatUtil {
    public static String formatDurantion(int duration) {
        duration = duration/1000;
        StringBuilder builder = new StringBuilder();
        if (duration < 60) {
            builder.append("00:").append(formatTimeNumber(duration));
            return builder.toString();
        } else {
            int minute = duration/60;
            builder.append(formatTimeNumber(minute)).append(":").append(formatTimeNumber(duration%60));
            return builder.toString();
        }

    }
    private static String formatTimeNumber(int number) {
        if (number < 10) {
            return "0"+number;
        }
        return String.valueOf(number);
    }

    public static String formatSize(long size) {
        return "";

    }
}
