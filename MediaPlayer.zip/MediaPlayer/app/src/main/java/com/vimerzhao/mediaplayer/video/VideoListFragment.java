package com.vimerzhao.mediaplayer.video;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


import com.vimerzhao.mediaplayer.R;

import java.util.ArrayList;
import java.util.List;


public class VideoListFragment extends Fragment {
    private RecyclerView mVideoListView;
    private Button mScanVideoBtn;
    private List<VideoBean> mVideoList;
    private VideoAdapter mAdapter;
    public static final String CUR_VIDEO = "CurrentVideo";
    public static final String VIDEO_LIST= "VideoList";
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_video_list, container, false);
        mVideoListView = rootView.findViewById(R.id.rv_video_list);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        manager.setOrientation(OrientationHelper.VERTICAL);
        mVideoListView.setLayoutManager(manager);
        mVideoListView.setItemAnimator(new DefaultItemAnimator());
        mScanVideoBtn = rootView.findViewById(R.id.btn_scan_video);
        mScanVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mVideoList = VideoUtils.scan(getActivity());
                mAdapter = new VideoAdapter(mVideoList, getActivity());
                mVideoListView.setAdapter(mAdapter);
                mScanVideoBtn.setVisibility(View.GONE);
                mVideoListView.setVisibility(View.VISIBLE);

                mAdapter.setListener(new VideoAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Bundle bundle = new Bundle();
                        bundle.putParcelableArrayList(VIDEO_LIST, (ArrayList<? extends Parcelable>) mVideoList);
                        bundle.putInt(CUR_VIDEO, position);
                        Intent intent = new Intent(getActivity(), VideoPlayActivity.class);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                });
            }
        });

        return rootView;
    }
}
