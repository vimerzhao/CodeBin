package com.vimerzhao.mediaplayer.music.presenter;


import android.content.Context;
import android.media.audiofx.Visualizer;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

import com.vimerzhao.mediaplayer.R;
import com.vimerzhao.mediaplayer.common.view.VisualizerView;
import com.vimerzhao.mediaplayer.music.model.MusicBean;
import com.vimerzhao.mediaplayer.music.model.MusicDatabaseLoclImpl;
import com.vimerzhao.mediaplayer.music.model.MusicDatabaseOnlineImpl;
import com.vimerzhao.mediaplayer.music.service.MusicPlayService;
import com.vimerzhao.mediaplayer.music.view.MusicListFragment;
import com.vimerzhao.mediaplayer.music.view.PlayActivity;

import java.util.ArrayList;
import java.util.List;

public class PlayPresenterImpl implements IPlayPresenter {
    private static IPlayPresenter playPresenter;
    private Handler mHandler = new Handler();


    public static IPlayPresenter getInstance() {
        if (playPresenter == null) {
            return new PlayPresenterImpl();
        }
        return playPresenter;
    }

    @Override
    public List<MusicBean> getLocalMusicList(Context context) {
        return MusicDatabaseLoclImpl.getInstance().getLocalMusicList(context);
    }

    @Override
    public List<MusicBean> getOnlineMusicList(String keyWords) {
        return MusicDatabaseOnlineImpl.getInstance().getOnlineMusicList(keyWords);
    }

    @Override
    public MusicPlayService prepareService(MusicPlayService playService, IBinder service,
                               ArrayList<MusicBean> playList, int index) {
        playService = ((MusicPlayService.MyBinder)service).getService();
        playService.setMusicList(playList);
        playService.setCurIndex(index);
        playService.init();
        playService.play();
        return playService;
    }

    @Override
    public Visualizer prepareVisualizer(Visualizer visualizer, final VisualizerView view, MusicPlayService service) {
        visualizer = new Visualizer(service.getPlayer().getAudioSessionId());
        visualizer.setEnabled(false);
        visualizer.setCaptureSize(Visualizer.getCaptureSizeRange()[0]);
        visualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
            @Override
            public void onWaveFormDataCapture(Visualizer visualizer, byte[] waveform, int samplingRate) {
                view.updateVisualizer(waveform);
            }

            @Override
            public void onFftDataCapture(Visualizer visualizer, byte[] fft, int samplingRate) {
                view.updateVisualizer(fft);
            }
        }, Visualizer.getMaxCaptureRate() / 2, false, true);
        visualizer.setEnabled(true);
        return visualizer;
    }

    @Override
    public void changeLoopMode(MusicPlayService service,PlayActivity activity) {
        if (service != null) {
            service.updateCurMode();
            switch (service.getCurMode()) {
                case MusicPlayService.LOOP_MODE:
                    activity.getLoopModeBtn().setImageResource(R.mipmap.btn_media_loop);
                    Toast.makeText(activity.getApplication(), "列表循环", Toast.LENGTH_SHORT).show();
                    break;
                case MusicPlayService.SINGLE_MODE:
                    activity.getLoopModeBtn().setImageResource(R.mipmap.btn_media_single);
                    Toast.makeText(activity.getApplication(), "单曲循环", Toast.LENGTH_SHORT).show();
                    break;
                case MusicPlayService.RANDOM_MODE:
                    activity.getLoopModeBtn().setImageResource(R.mipmap.btn_media_random);
                    Toast.makeText(activity.getApplication(), "随机播放", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    @Override
    public void playOrPause(MusicPlayService service, PlayActivity activity,
                            Handler handler, Runnable seekBarThread) {
        if (service == null) return;

        if (service.isPlaying()) {
            activity.getPlayPauseBtn().setImageResource(R.mipmap.btn_media_play);
            service.pause();
            handler.removeCallbacks(seekBarThread);
        } else{
            activity.getPlayPauseBtn().setImageResource(R.mipmap.btn_media_pause);
            service.play();
            handler.post(seekBarThread);
        }
    }

    @Override
    public void showLocalMusicList(MusicListFragment fragment) {
        fragment.setMusicList(getLocalMusicList(fragment.getActivity()));
        fragment.showMusicList();
    }

    @Override
    public void showOnlineMusicList(final MusicListFragment fragment) {
        new Thread() {
            @Override
            public void run() {
                super.run();
                fragment.setMusicList(getOnlineMusicList(fragment.getKeyWords()));
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        fragment.showMusicList();
                    }
                });
            }
        }.start();
    }
    private MusicPlayService playService;

}
