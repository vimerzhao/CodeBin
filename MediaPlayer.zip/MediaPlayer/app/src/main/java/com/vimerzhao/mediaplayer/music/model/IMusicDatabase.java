package com.vimerzhao.mediaplayer.music.model;


import android.content.Context;

import java.util.List;

public interface IMusicDatabase {
    List<MusicBean> getLocalMusicList(Context context);
    List<MusicBean> getOnlineMusicList(String keyWords);
}
