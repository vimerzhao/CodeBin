package com.vimerzhao.mediaplayer;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.vimerzhao.mediaplayer.music.view.MusicListFragment;
import com.vimerzhao.mediaplayer.video.VideoListFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int FRAGMENT_MUSIC = 0;
    private static final int FRAGMENT_VIDEO = 1;

    private ViewPager mViewPager;
    private List<Fragment> fragmentList;
    private ImageButton mMusicButton;
    private ImageButton mVideoButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        initViews();
    }

    private void initData() {
        fragmentList = new ArrayList<>();
        fragmentList.add(new MusicListFragment());
        fragmentList.add(new VideoListFragment());
    }

    private void initViews() {
        mViewPager = findViewById(R.id.vp_container);
        mViewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragmentList.get(position);
            }

            @Override
            public int getCount() {
                return fragmentList.size();
            }
        });

        mViewPager.setCurrentItem(FRAGMENT_MUSIC);

        mMusicButton = findViewById(R.id.ib_music);
        mMusicButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mViewPager.setCurrentItem(FRAGMENT_MUSIC);
            }
        });

        mVideoButton = findViewById(R.id.ib_video);
        mVideoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mViewPager.setCurrentItem(FRAGMENT_VIDEO);
            }
        });
    }
}
