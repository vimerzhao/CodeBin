package com.vimerzhao.mediaplayer.video;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.vimerzhao.mediaplayer.R;

import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoItemHolder> implements View.OnClickListener {
    private List<VideoBean> videoList;
    private Context context;
    private OnItemClickListener listener;
    private LayoutInflater layoutInflater;

    public VideoAdapter(List<VideoBean> videoList, Context context) {
        this.videoList = videoList;
        this.context = context;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public VideoItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.item_video_list, parent, false);
        VideoItemHolder holder = new VideoItemHolder(view);
        view.setOnClickListener(this);
        return holder;
    }

    @Override
    public void onBindViewHolder(VideoItemHolder holder, int position) {
        holder.number.setText(String.valueOf(position+1));
        holder.name.setText(videoList.get(position).getName());
        long size = videoList.get(position).getSize()/1024/1024;
        //考虑边界情况，需要单独出来处理

        int minute = videoList.get(position).getDuration()/1000/60;
        int second = videoList.get(position).getDuration()/1000%60;
        holder.info.setText("时长: " + minute + ":" + second + ",大小：" + size + "M");

        holder.itemView.setTag(position);
    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }

    @Override
    public void onClick(View v) {
        if (listener != null) {
            listener.onItemClick(v, (Integer) v.getTag());
        }
    }

    class VideoItemHolder  extends RecyclerView.ViewHolder{
        TextView number;
        TextView name;
        TextView info;
        public VideoItemHolder(View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.tv_number);
            name = itemView.findViewById(R.id.tv_name);
            info = itemView.findViewById(R.id.tv_info);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public void setListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}

