package com.vimerzhao.mediaplayer.music.view;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.vimerzhao.mediaplayer.R;
import com.vimerzhao.mediaplayer.music.adapter.MusicAdapter;
import com.vimerzhao.mediaplayer.music.model.MusicBean;
import com.vimerzhao.mediaplayer.music.presenter.IPlayPresenter;
import com.vimerzhao.mediaplayer.music.presenter.PlayPresenterImpl;
import com.vimerzhao.mediaplayer.music.service.MusicPlayService;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.BIND_AUTO_CREATE;


public class MusicListFragment extends Fragment {
    private RecyclerView mMusicListView;
    private List<MusicBean> mMusicList;
    private MusicAdapter mAdapter;
    private Button mScanMusicButton;
    private EditText mKeywordsEt;
    private Button mSearchBtn;
    private LinearLayout mSearchBar;
    public static final String CUR_MUSIC = "CurrentMusic";
    public static final String MUSIC_LIST= "MusicList";

    private IPlayPresenter playPresenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        playPresenter = PlayPresenterImpl.getInstance();

        View rootView = inflater.inflate(R.layout.fragment_music_list, container, false);
        mMusicListView = rootView.findViewById(R.id.rv_music_list);
        mKeywordsEt = rootView.findViewById(R.id.et_input_keywords);
        mSearchBtn = rootView.findViewById(R.id.btn_search);
        mSearchBar = rootView.findViewById(R.id.ll_search_bar);

        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        manager.setOrientation(OrientationHelper.VERTICAL);
        mMusicListView.setLayoutManager(manager);
        mMusicListView.setItemAnimator(new DefaultItemAnimator());
        mScanMusicButton = rootView.findViewById(R.id.btn_scan_music);
        mScanMusicButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPresenter.showLocalMusicList(MusicListFragment.this);
            }
        });

        mSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPresenter.showOnlineMusicList(MusicListFragment.this);
            }
        });
        return rootView;
    }

    public void setMusicList(List<MusicBean> mMusicList) {
        this.mMusicList = mMusicList;
    }

    public void showMusicList() {
       // mMusicList = playPresenter.getLocalMusicList(getActivity());
        mAdapter = new MusicAdapter(mMusicList, getActivity());
        mMusicListView.setAdapter(mAdapter);
        mScanMusicButton.setVisibility(View.GONE);
        mMusicListView.setVisibility(View.VISIBLE);
        mSearchBar.setVisibility(View.GONE);

        mAdapter.setListener(new MusicAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList(MUSIC_LIST, (ArrayList<? extends Parcelable>) mMusicList);
                bundle.putInt(CUR_MUSIC, position);
                Intent intent = new Intent(getActivity().getApplicationContext(), PlayActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    public String getKeyWords() {
        return mKeywordsEt.getText().toString();
    }

}

