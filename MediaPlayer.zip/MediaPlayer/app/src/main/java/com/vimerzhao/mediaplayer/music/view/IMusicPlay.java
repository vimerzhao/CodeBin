package com.vimerzhao.mediaplayer.music.view;


import android.app.Service;
import android.media.audiofx.Visualizer;

public interface IMusicPlay {
    void playNext();
    void playPrevious();
    void changeLoopMode();
    void playOrPause();

}
