package com.vimerzhao.mediaplayer.music.model;


import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

public class MusicDatabaseLoclImpl implements IMusicDatabase {
    private static IMusicDatabase musicDatabase;
    public static IMusicDatabase getInstance() {
        if (musicDatabase == null) {
            return new MusicDatabaseLoclImpl();
        }
        return musicDatabase;
    }

    @Override
    public List<MusicBean> getOnlineMusicList(String keyWords) {
        return null;
    }

    @Override
    public List<MusicBean> getLocalMusicList(Context context) {
        List<MusicBean> musicList = new ArrayList<>();
        Cursor cursor = context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                null, null, null, MediaStore.Audio.AudioColumns.IS_MUSIC);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                MusicBean musicBean = new MusicBean();
                musicBean.setName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)));
                musicBean.setSinger(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)));
                musicBean.setPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)));
                musicBean.setDuration(cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)));
                musicBean.setSize(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
                musicList.add(musicBean);
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        return musicList;
    }
}
