package com.vimerzhao.mediaplayer.video;


import android.os.Parcel;
import android.os.Parcelable;

public class VideoBean implements Parcelable {
    String name;
    String path;
    int duration;
    long size;

    public VideoBean() {
    }

    protected VideoBean(Parcel in) {
        name = in.readString();
        path = in.readString();
        duration = in.readInt();
        size = in.readLong();
    }

    public static final Creator<VideoBean> CREATOR = new Creator<VideoBean>() {
        @Override
        public VideoBean createFromParcel(Parcel in) {
            return new VideoBean(in);
        }

        @Override
        public VideoBean[] newArray(int size) {
            return new VideoBean[size];
        }
    };

    public void setName(String name) {
        this.name = name;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setSize(long size) {
        this.size = size;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public int getDuration() {
        return duration;
    }

    public long getSize() {
        return size;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(path);
        dest.writeInt(duration);
        dest.writeLong(size);
    }
}
