package com.vimerzhao.mediaplayer.music.service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.vimerzhao.mediaplayer.music.model.MusicBean;

import java.io.IOException;
import java.util.ArrayList;


public class MusicPlayService extends Service {
    private final IBinder binder = new MyBinder();
    private ArrayList<MusicBean> mMusicList;
    private int mCurIndex;
    private int mCurMode;//Single,Loop,random
    public final static int LOOP_MODE = 0;
    public final static int SINGLE_MODE = 1;
    public final static int RANDOM_MODE = 2;
    private final static int MODE_COUNT = 3;
    private MediaPlayer player;

    public void setMusicList(ArrayList<MusicBean> mMusicList) {
        this.mMusicList = mMusicList;
    }

    public void setCurIndex(int mCurIndex) {
        this.mCurIndex = mCurIndex;
    }

    public void setCurMode(int mCurMode) {
        this.mCurMode = mCurMode;
    }

    public void updateCurMode() {
        mCurMode = (mCurMode + 1) % MODE_COUNT;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        player = new MediaPlayer();
        mCurMode = LOOP_MODE;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public class MyBinder extends Binder {
        public MusicPlayService getService() {
            return MusicPlayService.this;
        }
    }

    private void prepare(String path) {
        try {
            player.reset();
            player.setDataSource(path);
            player.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                // 自动切换时也需要更新
                updateIndex(1);
                init();
                play();
            }
        });

    }

    public void play() {
        player.start();

    }

    public void pause() {
        player.pause();

    }

    private void updateIndex(int change) {
        switch (mCurMode) {
            case LOOP_MODE:
                mCurIndex = (mCurIndex + change + mMusicList.size()) % mMusicList.size();
                break;
            case RANDOM_MODE:
                mCurIndex = (int) (Math.random() * mMusicList.size());
                System.out.println(mCurIndex);
                break;
            case SINGLE_MODE:
                break;
        }

    }

    public void init() {
        prepare(mMusicList.get(mCurIndex).getPath());
    }

    public void next() {
        boolean isPlay = player.isPlaying();
        updateIndex(1);
        init();
        if (isPlay) {
            play();
        }
    }

    public void previous() {
        boolean isPlay = player.isPlaying();
        updateIndex(-1);
        init();
        if (isPlay) {
            play();
        }
    }

    public void modelChange() {

    }

    public int getCurMode() {
        return mCurMode;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }

    public boolean isPlaying() {
        return player.isPlaying();
    }

    public int getProgress() {
        if (player == null) return 1;
        return player.getCurrentPosition();
    }

    public int getDuration() {
        if (player == null) return 1;
        return player.getDuration();
    }
    public MediaPlayer getPlayer() {
        return player;
    }
    public String getName() {
        return mMusicList.get(mCurIndex).getName();
    }
    public void seekTo(int progress) {
        player.seekTo(player.getDuration()*progress/100);
    }
}
