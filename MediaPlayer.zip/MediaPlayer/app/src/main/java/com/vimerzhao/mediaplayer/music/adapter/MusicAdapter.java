package com.vimerzhao.mediaplayer.music.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.vimerzhao.mediaplayer.R;
import com.vimerzhao.mediaplayer.music.model.MusicBean;

import java.util.List;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.MusicItemHolder> implements View.OnClickListener {
    private List<MusicBean> musicList;
    private Context context;
    private OnItemClickListener listener;
    private LayoutInflater layoutInflater;

    public MusicAdapter(List<MusicBean> musicList, Context context) {
        this.musicList = musicList;
        this.context = context;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public MusicItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.item_music_list, parent, false);
        MusicItemHolder holder = new MusicItemHolder(view);
        view.setOnClickListener(this);
        return holder;
    }

    @Override
    public void onBindViewHolder(MusicItemHolder holder, int position) {
        holder.number.setText(String.valueOf(position+1));
        holder.name.setText(musicList.get(position).getName());
        long size = musicList.get(position).getSize()/1024/1024;
        //考虑边界情况，需要单独出来处理

        int minute = musicList.get(position).getDuration()/1000/60;
        int second = musicList.get(position).getDuration()/1000%60;
        holder.info.setText("歌手: " + musicList.get(position).getSinger() +
                ", 时长: " + minute + ":" + second + ",大小：" + size + "M");

        holder.itemView.setTag(position);
    }

    @Override
    public int getItemCount() {
        return musicList.size();
    }

    @Override
    public void onClick(View v) {
        if (listener != null) {
            listener.onItemClick(v, (Integer) v.getTag());
        }
    }

    class MusicItemHolder  extends RecyclerView.ViewHolder{
        TextView number;
        TextView name;
        TextView info;

        public MusicItemHolder(View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.tv_number);
            name = itemView.findViewById(R.id.tv_name);
            info = itemView.findViewById(R.id.tv_info);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public void setListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
