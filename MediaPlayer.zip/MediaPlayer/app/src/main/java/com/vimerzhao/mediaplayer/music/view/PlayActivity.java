package com.vimerzhao.mediaplayer.music.view;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.vimerzhao.mediaplayer.R;
import com.vimerzhao.mediaplayer.common.util.FormatUtil;
import com.vimerzhao.mediaplayer.common.util.ServiceUtil;
import com.vimerzhao.mediaplayer.common.view.VisualizerView;
import com.vimerzhao.mediaplayer.music.model.MusicBean;
import com.vimerzhao.mediaplayer.music.presenter.IPlayPresenter;
import com.vimerzhao.mediaplayer.music.presenter.PlayPresenterImpl;
import com.vimerzhao.mediaplayer.music.service.MusicPlayService;

import java.util.ArrayList;


public class PlayActivity extends AppCompatActivity implements IMusicPlay {
    private ArrayList<MusicBean> mPlayList;
    private int mCurIndex;
    private MusicPlayService playService;
    private ImageButton mLoopModeBtn;
    private ImageButton mPreviousBtn;
    private ImageButton mPlayPauseBtn;
    private ImageButton mNextBtn;
    private ImageButton mMusicListBtn;
    private TextView mCurTimeTv;
    private TextView mTotalTimeTv;
    private Visualizer mVisualizer;

    private VisualizerView mVisualizerView;
    private IPlayPresenter playPresenter;


    private SeekBar mMusicProgressSb;
    private Handler mHandler;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (playPresenter != null) {
                playService = playPresenter.prepareService(playService, service, mPlayList, mCurIndex);
                mVisualizer = playPresenter.prepareVisualizer(mVisualizer, mVisualizerView, playService);
            }
            mHandler.post(seekBarThread);
            if (mPlayPauseBtn != null) {
                mPlayPauseBtn.setImageResource(R.mipmap.btn_media_pause);
            }
            getSupportActionBar().setTitle(playService.getName());
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Toast.makeText(PlayActivity.this, "音乐停止", Toast.LENGTH_SHORT).show();
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_play);
        playPresenter = PlayPresenterImpl.getInstance();

        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        initData();
        initView();

        Intent intent = new Intent(getBaseContext(), MusicPlayService.class);
        bindService(intent, connection, BIND_AUTO_CREATE);
    }
    private void initData() {
        Bundle bundle = this.getIntent().getExtras();
        mPlayList = bundle.getParcelableArrayList(MusicListFragment.MUSIC_LIST);
        mCurIndex = bundle.getInt(MusicListFragment.CUR_MUSIC);
        mHandler = new Handler();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(connection);
    }

    private void initView() {
        mLoopModeBtn = findViewById(R.id.btn_loop_mode);
        mPreviousBtn = findViewById(R.id.btn_previous_music);
        mPlayPauseBtn = findViewById(R.id.btn_play_pause);
        mNextBtn = findViewById(R.id.btn_next_music);
        mMusicListBtn = findViewById(R.id.btn_music_list);
        mCurTimeTv = findViewById(R.id.tv_current_time);
        mTotalTimeTv = findViewById(R.id.tv_total_duration);
        mVisualizerView = findViewById(R.id.vv_music_figure);

        mLoopModeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeLoopMode();
            }
        });

        mPlayPauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playOrPause();
            }
        });



        mPreviousBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPrevious();
            }
        });

        mNextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playNext();
            }
        });


        mMusicProgressSb = findViewById(R.id.sb_music_progress);
        mMusicProgressSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                playService.seekTo(seekBar.getProgress());
            }
        });
    }

    Runnable seekBarThread = new Runnable() {
        @Override
        public void run() {
            if (playService != null) {

                mCurTimeTv.setText(FormatUtil.formatDurantion(playService.getProgress()));
                mTotalTimeTv.setText(FormatUtil.formatDurantion(playService.getDuration()));
                mMusicProgressSb.setProgress((playService.getProgress()*100)/playService.getDuration());
                mHandler.postDelayed(seekBarThread, 1000);
            }
        }
    };

    public ImageButton getLoopModeBtn() {
        return mLoopModeBtn;
    }

    public ImageButton getPlayPauseBtn() {
        return mPlayPauseBtn;
    }

    @Override
    public void playNext() {
        if (playService != null) {
            playService.next();
            getSupportActionBar().setTitle(playService.getName());
        }
    }

    @Override
    public void playPrevious() {
        if (playService != null) {
            playService.previous();
            getSupportActionBar().setTitle(playService.getName());
        }
    }

    @Override
    public void changeLoopMode() {
        playPresenter.changeLoopMode(playService, PlayActivity.this);
    }

    @Override
    public void playOrPause() {
        playPresenter.playOrPause(playService, PlayActivity.this, mHandler, seekBarThread);
    }
}
