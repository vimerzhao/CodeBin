package practice.mobilesecurity.chapter05.utils;

public class Constant {
    public static final String CONFIG = "config";
    public static final String LAST_SCAN = "lastVirusScan";
}
