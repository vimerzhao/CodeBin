package practice.mobilesecurity.chapter02.entity;

public class ContactInfo {
    public String id;
    public String name;
    public String phone;
}
