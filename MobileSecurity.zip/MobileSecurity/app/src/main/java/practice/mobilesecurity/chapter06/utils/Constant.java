package practice.mobilesecurity.chapter06.utils;

public class Constant {
    public static final String CACHE_SIZE = "cacheMemory";
}
