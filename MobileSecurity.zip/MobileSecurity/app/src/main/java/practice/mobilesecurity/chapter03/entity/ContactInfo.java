package practice.mobilesecurity.chapter03.entity;

/**
 * 联系人信息的实体类
 */
public class ContactInfo {

    public String id;
    public String name;
    public String phone;
}
