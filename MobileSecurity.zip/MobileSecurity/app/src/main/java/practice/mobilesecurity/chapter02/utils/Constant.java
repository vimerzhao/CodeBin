package practice.mobilesecurity.chapter02.utils;

public class Constant {
    public static final String CONFIG = "config";
    public static final String PROTECTING = "protecting";
    public static final String SIM = "sim";
    public static final String SAFE_PHONE = "safePhone";
}
