package practice.mobilesecurity.chapter06.entity;

import android.graphics.drawable.Drawable;

public class CacheInfo {
    public String packageName;
    public long cacheSize;
    public Drawable appIcon;
    public String appName;
}
