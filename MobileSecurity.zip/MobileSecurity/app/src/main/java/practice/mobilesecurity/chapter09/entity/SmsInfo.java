package practice.mobilesecurity.chapter09.entity;

public class SmsInfo {
    public  String body;
    public  String date;
    public  String type;
    public String address;
}
