package practice.mobilesecurity.chapter09.entity;

import android.graphics.drawable.Drawable;

public class AppInfo {
    public String packageName;
    public Drawable icon;
    public String appName;
    public String apkPath;
    public boolean isLock;
}