package practice.mobilesecurity.chapter05.entity;

import android.graphics.drawable.Drawable;

public class ScanAppInfo {
    public String appName;
    public boolean isVirus;
    public String packageName;
    public String description;
    public Drawable appIcon;
}
