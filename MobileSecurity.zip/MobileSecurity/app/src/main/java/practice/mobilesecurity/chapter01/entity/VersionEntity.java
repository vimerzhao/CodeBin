package practice.mobilesecurity.chapter01.entity;

public class VersionEntity {
    // version of apk in server
    public String versionCode;

    // version description
    public String description;

    // address of apk
    public String apkUrl;
}
