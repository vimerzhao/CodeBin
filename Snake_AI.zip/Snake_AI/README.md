# AI snake

## part 1
&emsp;&emsp;为了将主要精力集中在AI上，这里直接使用了一份已有 的贪吃蛇代码进行修改。代码来源[Creating A Snake Game Tutorial With HTML5](http://rembound.com/articles/creating-a-snake-game-tutorial-with-html5)

## part2
&emsp;&emsp;为了尽量少的改动源代码，只在函数`updateGame`中添加了以下代码（除去这行代码就是一个人工控制的贪吃蛇了）

```
	//to make snake own AI,ADD the method
    snake.AI_getDirection();
```

&emsp;&emsp;这样就使得AI接管了蛇方向的控制，AI部分的逻辑（即我所添加的代码）均已`ai`开头，放在以下结构中

```
    /****************************AI begin******************************************/
    my code...
    /****************************AI  end ******************************************/
```

&emsp;&emsp;对源代码做了部分修改，主要是修改了部分按键的功能，修改了蛇身增长的方式。

## 效果
* 优酷地址：http://v.youku.com/v_show/id_XMTc2ODc5OTgxNg==.html?from=y1.7-2
* youtube：https://www.youtube.com/watch?v=xlGARayPoy0
* 在线：https://zhaoyu1995.github.io/ai_snake_demo/snake.html

## 问题记录

* 按照预定路径走可能陷入无限循环，需要增加一个检查机制，走出困境