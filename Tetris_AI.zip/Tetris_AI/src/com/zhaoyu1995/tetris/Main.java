package com.zhaoyu1995.tetris;

import com.zhaoyu1995.tetris.ui.MainFrame;

public class Main {

    public static void main(String[] args) {
        MainFrame m = new MainFrame();
        m.setVisible(true);
    }
}
