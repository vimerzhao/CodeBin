package com.zhaoyu1995.tetris.exception;
public class GameException extends RuntimeException {

    public GameException(String s) {
        super(s);
    }
}