# 简介
&emsp;&emsp;一个**管理读书进度**的APP，因为之前没有找到合适的APP，于是只好自己做了一个。app-release.apk可以直接下载安装。整理记录在博客[做一个阅读管理APP](http://www.cnblogs.com/zhaoyu1995/p/5935950.html)中，效果如下：
![效果](http://7y09c1.com1.z1.glb.clouddn.com/reading效果.png)