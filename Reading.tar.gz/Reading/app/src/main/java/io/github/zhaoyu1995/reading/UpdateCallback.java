package io.github.zhaoyu1995.reading;


public interface UpdateCallback {
    void updateProgress(String name, int total);
}
