package io.github.zhaoyu1995.inter;

import io.github.zhaoyu1995.lexer.Word;
import io.github.zhaoyu1995.symbols.Type;

public class Id extends Expr {

	public int offset;     // relative address

	public Id(Word id, Type p, int b) { super(id, p); offset = b; }

//	public String toString() {return "" + op.toString() + offset;}
}
