package io.github.zhaoyu1995.inter;

import io.github.zhaoyu1995.lexer.Word;
import io.github.zhaoyu1995.symbols.Type;

public class Temp extends Expr {

   static int count = 0;
   int number = 0;

   public Temp(Type p) { super(Word.temp, p); number = ++count; }

   public String toString() { return "t" + number; }
}
