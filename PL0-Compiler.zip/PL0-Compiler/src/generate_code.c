﻿#include "PL0.h"
 /*
 * function :	add a record into symbol_table
 * parameter :	symbol_kind:one of >> const,var or procedure
 *				symbol_table_index:
 *				current_level: level of token
 *				var_offset:offset address(++)
 * return :
 * author :		zhaoyu
 * version :	1.0
 * last change: 2016-12-16
 * notes :		compelted
 */
void enter_symbol_table(enum object symbol_kind, int *symbol_table_index,
	int current_level, int *var_offset) {
	(*symbol_table_index)++;
	symbol_counter = *symbol_table_index;
	strcpy(symbol_table[(*symbol_table_index)].name, current_ident);
	symbol_table[(*symbol_table_index)].kind = symbol_kind;

	switch (symbol_kind) {
	case constant: {
		if (value_of_number > MAX_ADDRESS) {
			error(25);
			value_of_number = 0;
		}
		symbol_table[(*symbol_table_index)].val = value_of_number;
		break;
	}
	case variable: {
		symbol_table[(*symbol_table_index)].level = current_level;
		symbol_table[(*symbol_table_index)].adr = (*var_offset);
		(*var_offset)++;
		break;
	}
	case procedur: {
		symbol_table[(*symbol_table_index)].level = current_level;
		break;
	}
	}
}


/*
 * function :	search location of token
 * parameter :	ident：token name
 *				table_index: tail pointer of cur symbol table
 * return :		location or 0(not found)
 * author :		
 * version :	1.0
 * last change:	2016-12-16
 * notes :
 */
int position(char *ident, int  table_index) {
	int i;
	strcpy(symbol_table[0].name, ident);
	i = table_index;
	while (strcmp(symbol_table[i].name, ident) != 0) {
		i--;
	}
	return i;
}

 
/*
 * function :	generate virtual machine(vm) code
 * parameter :	x:instruction.f;
 *				y:instruction.l;
 *				z:instruction.a;
 * return :		0:success
 *				-1:error
 * author :		
 * version :	
 * last change:	2016-12-17
 * notes :		
 */
int generate_code(enum OPERATION x, int y, int z) {
	if (vm_pointer >= MAX_VM_CODE) {
		printf("Program too long"); 
		return -1;
	}
	code[vm_pointer].f = x;
	code[vm_pointer].l = y;
 	code[vm_pointer].a = z;
	vm_pointer++;
	return 0;
}



/*
 * function :	interpret
 * parameter :
 * return :	
 * author :		
 * version :	1.0
 * last change: 
 * notes :
*/
void interpret() {
	int instruction_pointer = 0, 
		instruction_base = 0, 
		stack_top = 0;  
	struct instruction cur_instruction; 
	/* data data_stack */
	int data_stack[STACK_SIZE];      
	printf("start pl0\n");
	data_stack[0] = data_stack[1] = data_stack[2] = 0;
	do {
		cur_instruction = code[instruction_pointer];  
		instruction_pointer++;
		switch (cur_instruction.f) {
		case LIT: {
			data_stack[stack_top] = cur_instruction.a;
			stack_top++;
			break;
		}
		case OPR: {
			switch (cur_instruction.a) {
			case 0: {
				stack_top = instruction_base;
				instruction_pointer = data_stack[stack_top + 2];
				instruction_base = data_stack[stack_top + 1];
				break;
			}
			case 1: {
				data_stack[stack_top - 1] = -data_stack[stack_top - 1];
				break;
			}
			case 2: {
				stack_top--;
				data_stack[stack_top - 1] = data_stack[stack_top - 1] + data_stack[stack_top];
				break;
			}
			case 3: {
				stack_top--;
				data_stack[stack_top - 1] = data_stack[stack_top - 1] - data_stack[stack_top];
				break;
			}
			case 4: {
				stack_top--;
				data_stack[stack_top - 1] = data_stack[stack_top - 1] * data_stack[stack_top];
				break;
			}
			case 5: {
				stack_top--;
				data_stack[stack_top - 1] = data_stack[stack_top - 1] / data_stack[stack_top];
				break;
			}
			case 6: {
				data_stack[stack_top - 1] = data_stack[stack_top - 1] % 2;
				break;
			}
			case 8: {
				stack_top--;
				data_stack[stack_top - 1] = (data_stack[stack_top - 1] == data_stack[stack_top]);
				break;
			}
			case 9: {
				stack_top--;
				data_stack[stack_top - 1] = (data_stack[stack_top - 1] != data_stack[stack_top]);
				break;
			}
			case 10: {
				stack_top--;
				data_stack[stack_top - 1] = (data_stack[stack_top - 1] < data_stack[stack_top]);
				break;
			}
			case 11: {
				stack_top--;
				data_stack[stack_top - 1] = (data_stack[stack_top - 1] >= data_stack[stack_top]);
				break;
			}
			case 12: {
				stack_top--;
				data_stack[stack_top - 1] = (data_stack[stack_top - 1] > data_stack[stack_top]);
				break;
			}
			case 13: {
				stack_top--;
				data_stack[stack_top - 1] = (data_stack[stack_top - 1] <= data_stack[stack_top]);
				break;
			}
			case 14: {
				printf("%d", data_stack[stack_top - 1]);
				stack_top--;
				break;
			}
			case 15: {
				printf("\n");
				break;
			}
			case 16: {
				printf(">>");
				scanf("%d", &(data_stack[stack_top]));
				stack_top++;
				break;
			}
			}
			break;
		}
		case LOD: {
			data_stack[stack_top] = data_stack[base(cur_instruction.l, data_stack, instruction_base) + cur_instruction.a];
			stack_top++;
			break;
		}
		case STO: {
			stack_top--;
			data_stack[base(cur_instruction.l, data_stack, instruction_base) + cur_instruction.a] = data_stack[stack_top];
			break;
		}
		case CAL: {
			data_stack[stack_top] = base(cur_instruction.l, data_stack, instruction_base); 
			data_stack[stack_top + 1] = instruction_base;
			data_stack[stack_top + 2] = instruction_pointer;
			instruction_base = stack_top;
			instruction_pointer = cur_instruction.a;/* jump */
			break;
		}
		case INT: {
			stack_top += cur_instruction.a;
			break;
		}
		case JMP: {
			instruction_pointer = cur_instruction.a;
			break;
		}
		case JPC: {
			stack_top--;
			if (data_stack[stack_top] == 0) {
				instruction_pointer = cur_instruction.a;
			}
			break;
		}
		}
	} while (instruction_pointer != 0);
}

/*
 * function :	return location
 * parameter :	layer_offset:
 *				stack:
 *				base:
 * return :
 * author :
 * version :
 * last change :
 * notes :
 */
int base(int layer_offset, int * stack, int base) {
	while (layer_offset>0) {
		base = stack[base];
		layer_offset--;
	}
	return base;
}
