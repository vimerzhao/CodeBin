#include "PL0.h"
/*
 * function :	init variable of program
 * parameter :	void
 * return :		void
 * author :		zhaoyu
 * version :	1.0
 * last change: 2016-12-15
 * notes :		completed
 */
void init_compiler() {
	for (int i = 0; i <= 255; i++) {
		ssym[i] = nul;
	}
	ssym['+'] = plus_symbol;
	ssym['-'] = minus_symbol;
	ssym['*'] = times_symbol;
	ssym['/'] = divide_symbol;
	ssym['('] = left_parentheses;
	ssym[')'] = right_parentheses;
	ssym['='] = equal_symbol;
	ssym[','] = comma_symbol;
	ssym['.'] = period;
	ssym['#'] = unequal_symbol;
	ssym[';'] = semicolon_symbol;
	/* set name of key words,from a-z,for binary-search */
	strcpy(&(word[0][0]), "begin");
	strcpy(&(word[1][0]), "call");
	strcpy(&(word[2][0]), "const");
	strcpy(&(word[3][0]), "do");
	strcpy(&(word[4][0]), "end");
	strcpy(&(word[5][0]), "if");
	strcpy(&(word[6][0]), "odd");
	strcpy(&(word[7][0]), "procedure");
	strcpy(&(word[8][0]), "read");
	strcpy(&(word[9][0]), "then");
	strcpy(&(word[10][0]), "var");
	strcpy(&(word[11][0]), "while");
	strcpy(&(word[12][0]), "write");

	/* set key words*/
	wsym[0] = begin_symbol;
	wsym[1] = call_symbol;
	wsym[2] = constant_symbol;
	wsym[3] = do_symbol;
	wsym[4] = end_symbol;
	wsym[5] = if_symbol;
	wsym[6] = odd_symbol;
	wsym[7] = procedure_symbol;
	wsym[8] = read_symbol;
	wsym[9] = then_symbol;
	wsym[10] = variable_symbol;
	wsym[11] = while_symbol;
	wsym[12] = write_symbol;

	/* init the name of vm(virtual machine) code */
	strcpy(&(vm_code_name[LIT][0]), "LIT");
	strcpy(&(vm_code_name[OPR][0]), "OPR");
	strcpy(&(vm_code_name[LOD][0]), "LOD");
	strcpy(&(vm_code_name[STO][0]), "STO");
	strcpy(&(vm_code_name[CAL][0]), "CAL");
	strcpy(&(vm_code_name[INT][0]), "INT");
	strcpy(&(vm_code_name[JMP][0]), "JMP");
	strcpy(&(vm_code_name[JPC][0]), "JPC");

	/* init symbol sets*/
	for (int i = 0; i<symbol_number; i++) {
		declare_begin_symbol[i] = false;
		statement_begin_symbol[i] = false;
		factor_begin_symbol[i] = false;
	}

	/* begin(FIRST SETS) symbol of declare*/
	declare_begin_symbol[constant_symbol] = true;
	declare_begin_symbol[variable_symbol] = true;
	declare_begin_symbol[procedure_symbol] = true;

	/*begin symbol of statement*/
	statement_begin_symbol[begin_symbol] = true;
	statement_begin_symbol[call_symbol] = true;
	statement_begin_symbol[if_symbol] = true;
	statement_begin_symbol[while_symbol] = true;

	/* begin symbol of factor */
	factor_begin_symbol[ident] = true;
	factor_begin_symbol[number_symbol] = true;
	factor_begin_symbol[left_parentheses] = true;

	error_counter = 0;
	symbol_counter = 0;
	current_char_position = vm_pointer = line_total_char = 0;
	ch = ' ';
	line_counter = 0;

	if (NULL == (fp_vm_code = fopen("fp_vm_code.txt", "w")) ||
		NULL == (fp_symbol_table = fopen("fp_symbol_table.txt", "w")) ||
		NULL == (fp_source_code = fopen("fp_source_code.txt", "w"))) {
		printf("fopen error!\n");
		exit(-1);
	}


	/* default */
	listswitch = true;
	tableswitch = true;

}

/*
* function :	
* parameter :	void
* return :		void
* author :		zhaoyu
* version :	1.0
* last change: 2016-12-15
* notes :		completed
*/
void clean_compiler() {
	if (EOF == fclose(fp_vm_code) || 
		EOF == fclose(fp_source_code) ||
		EOF == fclose(fp_symbol_table)) {
		printf("fclose error!\n");
		exit(-1);
	}

}