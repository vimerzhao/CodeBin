/*********************************************************************************
*						PL/0 Compiler											 *
*			origin:		������ԭ�������廪�� 2e��									 *
*			modify:		zhaoyu1995												 *
*			email:		zhaoyu1995.com@gamil.com								 *
*			blog:		http://www.cnblogs.com/zhaoyu1995/						 *
*																				 *
*			version:	1.0(��ԭ�����������֯)									 *
*							1.1													 *
**********************************************************************************/

#include"PL0.h"
/* ATTENTION: I add some paramenters in settings when debug in vs2015 */
int main(int argc,char **argv) {
	bool nxtlev[symbol_number];
	if (argc <= 1) {
		printf("please enter_symbol_table filename!");
		return 1;
	}

	if (NULL != (fin = fopen(argv[1], "r"))) {
		init_compiler();
		if (-1 != get_token()) {
			addset(nxtlev, declare_begin_symbol, statement_begin_symbol, symbol_number);
			nxtlev[period] = true;
			if (-1 != block(0, 0, nxtlev)) {
				listcode();
				output_symbol_table();
			} else {
				return -1;
			}
			if (kind_of_token != period) {
				error(9);
			}

			if (error_counter == 0) {
				interpret();
			} else {
				printf("Errors in pl/0 program");
			}
		}
	} else {
		printf("Can't open file! \n");
	}	
	clean_compiler();
	if (EOF == fclose(fin)) {
		return -1;
	}
	getchar();

	return 0;
}
