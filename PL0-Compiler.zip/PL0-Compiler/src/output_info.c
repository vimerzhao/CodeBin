#include "PL0.h"

/*
* function :
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
void output_symbol_table(void) {
	for (int i = 1; i <= symbol_counter; i++) {
		switch (symbol_table[i].kind) {
		case constant:
			//printf("%d\tconst\t%s\t\t", i, symbol_table[i].name);
			//printf("val=%d\n", symbol_table[i].val);
			fprintf(fp_symbol_table, "%d\tconst\t%s\t\t", i, symbol_table[i].name);
			fprintf(fp_symbol_table, "val=%d\n", symbol_table[i].val);
			break;
		case variable:
			//printf("%d\tvar\t\t%s\t\t", i, symbol_table[i].name);
			//printf("current_level=%d\t\taddr=%d\n", symbol_table[i].level, symbol_table[i].adr);
			fprintf(fp_symbol_table, "%d\tvar\t\t%s\t\t", i, symbol_table[i].name);
			fprintf(fp_symbol_table, "current_level=%d\t\taddr=%d\n", symbol_table[i].level, symbol_table[i].adr);
			break;
		case procedur:
			//printf("%d\tproc\t%s\t\t", i, symbol_table[i].name);
			//printf("current_level=%d\t\taddr=%d\t\tsize=%d\n", symbol_table[i].level, symbol_table[i].adr, symbol_table[i].size);
			fprintf(fp_symbol_table, "%d\tproc\t%s\t\t", i, symbol_table[i].name);
			fprintf(fp_symbol_table, "current_level=%d\t\taddr=%d\t\tsize=%d\n", symbol_table[i].level, symbol_table[i].adr, symbol_table[i].size);
			break;
		}
	}
}

/*
* function :
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
void listcode() {
	if (listswitch) {
		for (int i = 0; i < vm_pointer; i++) {
			//printf("%d %s %d %d\n", i, vm_code_name[code[i].f], code[i].l, code[i].a);
			fprintf(fp_vm_code, "%d %s %d %d\n", i, vm_code_name[code[i].f], code[i].l, code[i].a);
		}
	}
}