#include "PL0.h"

/*
 * function :	main part of this compiler
 * parameter :	current_level:
 *				table_index:
 *				token_end_set:
 * return :		void
 * author :		zhaoyu
 * version :	1.0
 * last change: 2016-12-15
 * notes :		completed
 */
int block(int current_level, int table_index, bool* token_end_set) {
	/* reserved space,for more info see manual */
	int procedure_size = 3;

	int initial_table_index = table_index;  

	int initial_vm_pointer = vm_pointer;

	bool next_symbol_set[symbol_number];
	
	symbol_table[table_index].adr = vm_pointer;
	generate_code_do(JMP, 0, 0);
	if (current_level > MAX_LEVEL) {
		error(26);
	}

	do {
		/* constant */
		if (kind_of_token == constant_symbol) { 
			get_token_do;
			do {
				constant_declaration_do(&table_index, current_level, &procedure_size);

				while (kind_of_token == comma_symbol) {
					get_token_do;
					constant_declaration_do(&table_index, current_level, &procedure_size);
				}
				if (kind_of_token == semicolon_symbol) {
					get_token_do;
				} else {
					error(5);
				}
			} while (kind_of_token == ident);
		}
		/* variable(like constant)*/
		if (kind_of_token == variable_symbol) {
			get_token_do;
			do {
				var_declaration_do(&table_index, current_level, &procedure_size);
				while (kind_of_token == comma_symbol) {
					get_token_do;
					var_declaration_do(&table_index, current_level, &procedure_size);
				}
				if (kind_of_token == semicolon_symbol) {
					get_token_do;
				} else {
					error(5);
				}
			} while (kind_of_token == ident);
		}
		/* procedure */
		while (kind_of_token == procedure_symbol) {
			get_token_do;
			if (kind_of_token == ident) {
				enter_symbol_table(procedur, &table_index, current_level, &procedure_size);
				get_token_do;
			} else {
				error(4);
			}
			if (kind_of_token == semicolon_symbol) {
				get_token_do;
			} else {
				error(5);
			}
			memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
			next_symbol_set[semicolon_symbol] = true;
			if (-1 == block(current_level + 1, table_index, next_symbol_set)) {
				return -1;/*�ݹ����*/
			}

			if (kind_of_token == semicolon_symbol) {
				get_token_do;
				memcpy(next_symbol_set, statement_begin_symbol, sizeof(bool)*symbol_number);
				next_symbol_set[ident] = true;
				next_symbol_set[procedure_symbol] = true;
				test_do(next_symbol_set, token_end_set, 6);
			} else {
				error(5);
			}
		}
		
		/* update sets*/
		memcpy(next_symbol_set, statement_begin_symbol, sizeof(bool)*symbol_number);
		next_symbol_set[ident] = true;
		next_symbol_set[period] = true;

		test_do(next_symbol_set, declare_begin_symbol, 7);
	} while (inset(kind_of_token, declare_begin_symbol));

	/* update entry */
	code[symbol_table[initial_table_index].adr].a = vm_pointer;                    

	/* update location of cur procedure */
	symbol_table[initial_table_index].adr = vm_pointer;                            
	
	/* update size of precedure*/
	symbol_table[initial_table_index].size = procedure_size;

	generate_code_do(INT, 0, procedure_size);
	
	/* update sets*/
	memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
	next_symbol_set[semicolon_symbol] = true;
	next_symbol_set[end_symbol] = true;

	statement_do(next_symbol_set, &table_index, current_level);

	/* release code */
	generate_code_do(OPR, 0, 0); 

	/* no end set for block */
	memset(next_symbol_set, 0, sizeof(bool)*symbol_number); 	
	test(token_end_set, next_symbol_set, 8);
	return 0;
}

/*
* function : 
* parameter :
* author :
* version :
* last change :
* notes :
*/
int statement(bool* token_end_set, int * symbol_table_index, int current_level) {
	int pos, cur_vm_pointer, loop_export;
	bool next_symbol_set[symbol_number];
	if (kind_of_token == ident) {
		pos = position(current_ident, *symbol_table_index);
		if (0 == pos) {
			error(11);
		} else {
			if (symbol_table[pos].kind != variable) {
				error(12);
				pos = 0;
			} else {
				get_token_do;
				if (kind_of_token == assign_symbol) {
					get_token_do;
				} else {
					error(13);
				}
				memcpy(next_symbol_set, token_end_set, sizeof(bool)* symbol_number);
				expression_do(next_symbol_set, symbol_table_index, current_level);
				if (pos != 0) {
					generate_code_do(STO, current_level - symbol_table[pos].level, symbol_table[pos].adr);
				}
			}
		}
	} else {
		if (kind_of_token == read_symbol) {
			get_token_do;
			if (kind_of_token != left_parentheses) {
				error(34);
			} else {
				do {
					get_token_do;
					if (kind_of_token == ident) {
						pos = position(current_ident, *symbol_table_index);
					} else {
						pos = 0;
					}
					if (pos == 0) {
						error(35);
					} else {
						generate_code_do(OPR, 0, 16);
						generate_code_do(STO, current_level - symbol_table[pos].level, symbol_table[pos].adr);
					}
					get_token_do;
				} while (kind_of_token == comma_symbol);
			}
			if (kind_of_token != right_parentheses) {
				error(27);
				while (!inset(kind_of_token, token_end_set)) {
					get_token_do;
				}
			} else {
				get_token_do;
			}
		} else {
			if (kind_of_token == write_symbol) {
				get_token_do;
				if (kind_of_token == left_parentheses) {
					do {
						get_token_do;
						memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
						next_symbol_set[right_parentheses] = true;
						next_symbol_set[comma_symbol] = true;
						expression_do(next_symbol_set, symbol_table_index, current_level);

						generate_code_do(OPR, 0, 14);
					} while (kind_of_token == comma_symbol);
					if (kind_of_token != right_parentheses) {
						error(27);
					} else {
						get_token_do;
					}
				}
				generate_code_do(OPR, 0, 15);
			} else {
				if (kind_of_token == call_symbol) {
					get_token_do;
					if (kind_of_token != ident) {
						error(14);
					} else {
						pos = position(current_ident, *symbol_table_index);
						if (pos == 0) {
							error(11);
						} else {
							if (symbol_table[pos].kind == procedur) {
								generate_code_do(CAL, current_level - symbol_table[pos].level, symbol_table[pos].adr);
							} else {
								error(15);
							}
						}
						get_token_do;
					}
				} else {
					if (kind_of_token == if_symbol) {
						get_token_do;
						memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
						next_symbol_set[then_symbol] = true;
						next_symbol_set[do_symbol] = true;
						condition_do(next_symbol_set, symbol_table_index, current_level);
					
						if (kind_of_token == then_symbol) {
							get_token_do;
						} else {
							error(16);
						}
						cur_vm_pointer = vm_pointer;
						
						/* 0 for temp ,*/
						generate_code_do(JPC, 0, 0);
						statement_do(token_end_set, symbol_table_index, current_level);
						
						/* now update the entry of statement(if true) */
						code[cur_vm_pointer].a = vm_pointer;
					} else {
						if (kind_of_token == begin_symbol) {
							get_token_do;
							memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
							next_symbol_set[semicolon_symbol] = true;
							next_symbol_set[end_symbol] = true;
							statement_do(next_symbol_set, symbol_table_index, current_level);

							while (inset(kind_of_token, statement_begin_symbol) || kind_of_token == semicolon_symbol) {
								if (kind_of_token == semicolon_symbol) {
									get_token_do;
								} else {
									error(10);
								}
								statement_do(next_symbol_set, symbol_table_index, current_level);
							}
							if (kind_of_token == end_symbol) {
								get_token_do;
							} else {
								error(17); 
							}
						} else {
							if (kind_of_token == while_symbol) {
								cur_vm_pointer = vm_pointer; 
								get_token_do;
								memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
								next_symbol_set[do_symbol] = true;
								condition_do(next_symbol_set, symbol_table_index, current_level); 

								loop_export = vm_pointer; 

								/* 0 for temp, export unknow */
								generate_code_do(JPC, 0, 0);
								if (kind_of_token == do_symbol) {
									get_token_do;
								} else {
									error(18);      /*ȱ��do*/
								}
								statement_do(token_end_set, symbol_table_index, current_level); /*loop*/
								generate_code_do(JMP, 0, cur_vm_pointer);/* return to judge again */
								code[loop_export].a = vm_pointer;
							} else {
								memset(next_symbol_set, 0, sizeof(bool)*symbol_number);
								test_do(token_end_set, next_symbol_set, 19);
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

/*
* function :
* parameter :
* author :
* version :
* last change :
* notes :
*/
int expression(bool*token_end_set, int*symbol_table_index, int current_level) {
	enum symbol front_operator;
	bool next_symbol_set[symbol_number];
	if (kind_of_token == plus_symbol || kind_of_token == minus_symbol) {
		front_operator = kind_of_token;
		get_token_do;

		memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
		next_symbol_set[plus_symbol] = true;
		next_symbol_set[minus_symbol] = true;
		term_do(next_symbol_set, symbol_table_index, current_level);

		if (front_operator == minus_symbol) {
			generate_code_do(OPR, 0, 1);   
		}
	} else {
		/* if there is no error check ,here is one line code */
		memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
		next_symbol_set[plus_symbol] = true;
		next_symbol_set[minus_symbol] = true;
		term_do(next_symbol_set, symbol_table_index, current_level);
	}

	while (kind_of_token == plus_symbol || kind_of_token == minus_symbol) {
		front_operator = kind_of_token;
		get_token_do;
		memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
		next_symbol_set[plus_symbol] = true;
		next_symbol_set[minus_symbol] = true;
		term_do(next_symbol_set, symbol_table_index, current_level);
		if (front_operator == plus_symbol) {
			generate_code_do(OPR, 0, 2);	/*add*/
		} else {
			generate_code_do(OPR, 0, 3);	/*minus_symbol*/
		}
	}
	return 0;
}

/*
* function :
* parameter :
* author :
* version :
* last change :
* notes :
*/
int term(bool*token_end_set, int *symbol_table_index, int current_level) {
	enum symbol front_operator;
	bool next_symbol_set[symbol_number];
	
	/* deal with factor,but should prepare for error check */
	memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
	next_symbol_set[times_symbol] = true;
	next_symbol_set[divide_symbol] = true;
	factor_do(next_symbol_set, symbol_table_index, current_level);

	while (kind_of_token == times_symbol || kind_of_token == divide_symbol) {
		front_operator = kind_of_token;
		get_token_do;
		factor_do(next_symbol_set, symbol_table_index, current_level);
		if (front_operator == times_symbol) {
			generate_code_do(OPR, 0, 4);
		} else {
			generate_code_do(OPR, 0, 5);
		}
	}
	return 0;
}

/*
* function :
* parameter :
* author :
* version :
* last change :
* notes :
*/
int factor(bool*token_end_set, int *symbol_table_index, int current_level) {
	int pos;
	bool next_symbol_set[symbol_number];
	test_do(factor_begin_symbol, token_end_set, 24);

	while (inset(kind_of_token, factor_begin_symbol))	{
		if (kind_of_token == ident) {
			pos = position(current_ident, *symbol_table_index);
			if (pos == 0) {
				error(11);
			} else {
				switch (symbol_table[pos].kind) {
				case constant: {
					generate_code_do(LIT, 0, symbol_table[pos].val);
					break;
				}
				case variable: {
					generate_code_do(LOD, current_level - symbol_table[pos].level, symbol_table[pos].adr);
					break;
				}
				case procedur: {
					error(21);
					break;
				}
				}
			}
			get_token_do;
		} else {
			if (kind_of_token == number_symbol) {
				if (value_of_number > MAX_ADDRESS) {
					error(25);
					value_of_number = 0;
				}
				generate_code_do(LIT, 0, value_of_number);
				get_token_do;
			} else {
				if (kind_of_token == left_parentheses) {
					get_token_do;

					memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
					next_symbol_set[right_parentheses] = true;
					expression_do(next_symbol_set, symbol_table_index, current_level);
					
					if (kind_of_token == right_parentheses) {
						get_token_do;
					} else {
						error(22);
					}
				}
				test_do(token_end_set, factor_begin_symbol, 23);
			}
		}
	}
	return 0;
}

/*
* function :
* parameter :
* author :
* version :
* last change :
* notes :
*/
int condition(bool* token_end_set, int* symbol_table_index, int current_level) {
	enum symbol relation_operator;
	bool next_symbol_set[symbol_number];
	if (kind_of_token == odd_symbol) {
		get_token_do;
		expression_do(token_end_set, symbol_table_index, current_level);
		generate_code_do(OPR, 0, 6);
	} else {
		memcpy(next_symbol_set, token_end_set, sizeof(bool)*symbol_number);
		next_symbol_set[equal_symbol] = true;
		next_symbol_set[unequal_symbol] = true;
		next_symbol_set[less_symbol] = true;
		next_symbol_set[less_equal_symbol] = true;
		next_symbol_set[greater_symbol] = true;
		next_symbol_set[greater_equal_symbol] = true;
		expression_do(next_symbol_set, symbol_table_index, current_level);

		if (kind_of_token != equal_symbol && kind_of_token != unequal_symbol && 
			kind_of_token != less_symbol && kind_of_token != less_equal_symbol &&
			kind_of_token != greater_symbol && kind_of_token != greater_equal_symbol) {
			error(20);
		} else {
			relation_operator = kind_of_token;
			get_token_do;
			expression_do(token_end_set, symbol_table_index, current_level);
			switch (relation_operator) {
			case equal_symbol: {
				generate_code_do(OPR, 0, 8);
				break;
			}
			case unequal_symbol: {
				generate_code_do(OPR, 0, 9);
				break;
			}
			case less_symbol: {
				generate_code_do(OPR, 0, 10);
				break;
			}
			case greater_equal_symbol: {
				generate_code_do(OPR, 0, 11);
				break;
			}
			case greater_symbol: {
				generate_code_do(OPR, 0, 12);
				break;
			}
			case less_equal_symbol: {
				generate_code_do(OPR, 0, 13);
				break;
			}
			}
		}
	}
	return 0;
}

/*
* function :
* parameter :
* author :
* version :
* last change :
* notes :
*/
int constant_declaration(int *symbol_table_index, int current_level, int *  var_offset) {
	if (kind_of_token == ident) {
		get_token_do;
		if (kind_of_token == equal_symbol || kind_of_token == assign_symbol) {
			if (kind_of_token == assign_symbol) {
				error(1);
			}
			get_token_do;
			if (kind_of_token == number_symbol) {
				enter_symbol_table(constant, symbol_table_index, current_level, var_offset);
				get_token_do;
			} else {
				error(2); 
			}
		} else {
			error(3);
		}
	} else {
		error(4);
	}
	return 0;
}

/*
* function :
* parameter :
* author :
* version :
* last change :
* notes :
*/
int variable_declaration(int * symbol_table_index, int current_level, int * var_offset) {
	if (kind_of_token == ident) {
		enter_symbol_table(variable, symbol_table_index, current_level, var_offset);
		get_token_do;
	} else {
		error(4);
	}
	return 0;
}
