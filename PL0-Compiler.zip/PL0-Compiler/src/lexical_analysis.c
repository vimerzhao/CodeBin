﻿#include "PL0.h"

 /*
 * function : read a line, called by get_token()
 * parameter : 
 * author : zhaoyu
 * version : 1.0
 * last change : 2016-12-16
 * notes : completed
 */
int get_char() {
	if (current_char_position == line_total_char) {
		if (feof(fin)) {
			printf("program incomplete");
			return -1;
		}
		line_total_char = 0;
		current_char_position = 0;
		fprintf(fp_source_code,"%d\t", vm_pointer);
		ch = ' ';
		//read a line
		line_counter++;
		while ('\n' != ch) {
			//fscanf(fin,"%c",&ch)
			if (EOF == fscanf(fin, "%c", &ch)) {
				line_cache[line_total_char] = 0;
				break;
			}
			// add function of comment
			if ('!' == ch) {
				while ('\n' != ch) {
					fscanf(fin, "%c", &ch);
				}
			}
			fprintf(fp_source_code,"%c", ch);
			line_cache[line_total_char] = ch;
			line_total_char++;
		}
	}

	//get next char
	ch = line_cache[current_char_position];
	current_char_position++;
	return 0;
}

/*
* function : get a token
* parameter :
* author : zhaoyu
* version : 1.0
* last change : 2016-12-16
* notes : completed
*/
int get_token() {
	int search_buttom, search_top, word_counter;
	
	/* cache for a key current_word or a ident */
	char current_word[MAX_IDENT_LENGTH + 1];
	
	/* skip space tab and enter_symbol_table */
	while (ch == ' ' || ch == '\n' || ch == '\t') {
		get_char_do;
	}

	if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
		word_counter = 0;
		do {
			if (word_counter<MAX_IDENT_LENGTH) {
				current_word[word_counter] = ch;
				word_counter++;
			}
			get_char_do;
		} while ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9'));
		current_word[word_counter] = 0;
		strcpy(current_ident, current_word);

		search_buttom = 0;
		search_top = key_words_number - 1;
		do {
			word_counter = (search_buttom + search_top) / 2;
			if (strcmp(current_ident, word[word_counter]) <= 0) {
				search_top = word_counter - 1;
			}
			if (strcmp(current_ident, word[word_counter]) >= 0) {
				search_buttom = word_counter + 1;
			}

		} while (search_buttom <= search_top);

		if (search_buttom - 1 > search_top) {
			kind_of_token = wsym[word_counter];
		} else {
			kind_of_token = ident;
		}
	} else {
		if (ch >= '0' && ch <= '9') {
			word_counter = 0;
			value_of_number = 0;
			kind_of_token = number_symbol;

			/* get value of number_symbol */
			do {
				value_of_number = 10 * value_of_number + ch - '0';
				word_counter++;
				get_char_do;
			} while (ch >= '0' && ch <= '9');

			/* test the bit of number_symbol, no more than 14 */
			word_counter--;
			if (word_counter > MAX_NUMBER_BIT) {
				error(30);
			}
		} else {/* check :=  >= > <= <= # */
			if (ch == ':') {
				get_char_do;
				if (ch == '=') {
					kind_of_token = assign_symbol;
					get_char_do;
				} else {
					/* unexpected symbol */
					kind_of_token = nul;            
				}
			} else {
				if (ch == '<') {
					get_char_do;
					if (ch == '=') {
						kind_of_token = less_equal_symbol;
						get_char_do;
					} else {
						kind_of_token = less_symbol;
					}
				} else {
					if (ch == '>')
					{
						get_char_do;
						if (ch == '=') {
							kind_of_token = greater_equal_symbol;
							get_char_do;
						} else {
							kind_of_token = greater_symbol;
						}
					} else { /* default nul */
						kind_of_token = ssym[ch];
						if (kind_of_token != period) {
							get_char_do;
						}
					}
				}
			}
		}
	}
	return 0;
}