#ifndef _PL0_H_
#define _PL0_H_
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>	/* exit */

typedef enum {
	false,
	true
}bool;

#define key_words_number 13                 
#define MAX_SYMBOL_NUMBER 100           
#define MAX_NUMBER_BIT  14        
#define MAX_IDENT_LENGTH 10  
#define MAX_ADDRESS 2047
#define MAX_LEVEL 3     
#define MAX_VM_CODE 200
#define STACK_SIZE 500

enum symbol {
	nul,ident, number_symbol, plus_symbol, minus_symbol,
	times_symbol, divide_symbol, odd_symbol, equal_symbol, unequal_symbol,
	less_symbol, less_equal_symbol, greater_symbol, greater_equal_symbol, left_parentheses,
	right_parentheses, comma_symbol, semicolon_symbol, period, assign_symbol,
	begin_symbol, end_symbol, if_symbol, then_symbol, while_symbol,
	write_symbol, read_symbol, do_symbol, call_symbol, constant_symbol,
	variable_symbol, procedure_symbol,
};
#define symbol_number 32

/*types in symbol table*/
enum object {
	constant,
	variable,
	procedur,
};


enum OPERATION {
	LIT, OPR, LOD, STO, CAL, INT, JMP, JPC,
};
#define OPERATION_NUMBER 8

struct instruction {
	enum OPERATION f;
	int l;
	int a;
};

FILE *fp_symbol_table;
FILE *fp_vm_code;
FILE *fp_source_code;
FILE *fin;
FILE *fout;

bool tableswitch;
bool listswitch;

char ch;
enum symbol kind_of_token;
char current_ident[MAX_IDENT_LENGTH + 1];
int  value_of_number;
int current_char_position, line_total_char;
int vm_pointer;	/*pointer of vm code*/
char line_cache[81];
struct instruction code[MAX_VM_CODE];
char word[key_words_number][MAX_IDENT_LENGTH];
enum symbol wsym[key_words_number];
enum symbol ssym[256];
char vm_code_name[OPERATION_NUMBER][5];
bool declare_begin_symbol[symbol_number];
bool statement_begin_symbol[symbol_number];
bool factor_begin_symbol[symbol_number];
char fname[MAX_IDENT_LENGTH];
int error_counter;
int symbol_counter;
int  line_counter;

struct tablestruct {
	char name[MAX_IDENT_LENGTH];  
	enum object kind;                         /* const��var or procedure*/
	int val;                                  /* only for const*/
	int level;                                /* for var and procedure */
	int adr;                                  /* for var and procedure */
	int size;                                 /* only for procedure */
};

struct tablestruct symbol_table[MAX_SYMBOL_NUMBER];



#define get_token_do							if(-1==get_token())return -1
#define get_char_do                             if(-1==get_char())return -1
#define test_do(a,b,c)							if(-1==test(a,b,c))return -1
#define generate_code_do(a,b,c)                 if(-1==generate_code(a,b,c))return -1
#define expression_do(a,b,c)					if(-1==expression(a,b,c))return -1
#define factor_do(a,b,c)						if(-1==factor(a,b,c))return -1
#define term_do(a,b,c)							if(-1==term(a,b,c))return -1
#define condition_do(a,b,c)						if(-1==condition(a,b,c))return -1
#define statement_do(a,b,c)						if(-1==statement(a,b,c))return -1
#define constant_declaration_do(a,b,c)			if(-1==constant_declaration(a,b,c))return -1
#define var_declaration_do(a,b,c)               if(-1==variable_declaration(a,b,c))return -1

void error(int n);
int get_token();
int get_char();
void init_compiler();
int generate_code(enum OPERATION x, int y, int z);
int test(bool*s1, bool*s2, int n);
int inset(int e, bool*s);
int addset(bool*sr, bool*s1, bool*s2, int n);
int subset(bool*sr, bool*s1, bool*s2, int n);
int mulset(bool*sr, bool*s1, bool*s2, int n);
int block(int lev, int tx, bool* fsys);
void interpret();
int factor(bool* fsys, int* ptx, int lev);
int term(bool*fsys, int*ptx, int lev);
int condition(bool*fsys, int*ptx, int lev);
int expression(bool*fsys, int*ptx, int lev);
int statement(bool*fsys, int*ptx, int lev);
void listcode(void);
int variable_declaration(int* ptx, int lev, int* pdx);
int constant_declaration(int* ptx, int lev, int* pdx);
int position(char* idt, int tx);
void enter_symbol_table(enum object k, int* ptx, int lev, int* pdx);
int base(int l, int* s, int b);
void output_symbol_table(void);
void clean_compiler();
#endif