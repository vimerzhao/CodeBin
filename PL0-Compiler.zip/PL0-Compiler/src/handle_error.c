#include "PL0.h"




 /*
 * function :	test if there is errors
 * parameter :	symbol_begin��token we need
 *				symbol_end: token set for handle error
 *				n: kind of error
 * return :		0:pass test
 * author :		
 * version :
 * last change :2016-12-17
 * notes :		see developer manual for details
 */
int test(bool* symbol_begin, bool* symbol_end, int n) {
	if (!inset(kind_of_token, symbol_begin)) {
		error(n);
		while ((!inset(kind_of_token, symbol_begin)) && (!inset(kind_of_token, symbol_end))) {
			get_token_do;
		}
	}
	return 0;
}


/* error info */
char error_info[30][80] = {
	{ "" },
	{ "Use = instead of :=." },/*1*/
	{ "= must be followed by a number." },
	{ "constant must be followed by =." },
	{ "const, var, procedure must be followed by identifier." },
	{ "Semicolon or comma missing." },
	{ "Incorrect symbol after procedure declaration." },/*6*/
	{ "Statement expected." },
	{ "Incorrect symbol after statement part in block" },
	{ "Period expected." },
	{ "Semicolon between statements missing." },
	{ "Undeclared identifier." },/*11*/
	{ "Assignment to constant or procedure is not allowed." },
	{ "Assignment operator expected." },
	{ "call must be followed by an identifier." },
	{ "Call of a constant or variable is meaningless." },
	{ "then expected." },/*16*/
	{ "Semicolon or end expected." },
	{ "do expected." },
	{ "Incorrect symbol following statement." },
	{ "Relational operator expected." },
	{ "Expression must not contain a procedure identifier." },/*21*/
	{ "Right parenthesis missing." },
	{ "The preceding factor cannot begin with this symbol." },
	{ "An expression cannot begin with this symbol." },
	{ "This number is too large." },
	{ "read must be followed by an identifier." },/*26*/
	{ "" },
	{ "" },
	{ "" }
};

/*
* function :
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
void error(int n) {
	printf("line:%d:\t%s\n", line_counter-1, error_info[n]);
	error_counter++;
}


/*
* function :	realize the calculation of sets by array
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
int inset(int e, bool* s) {
	return s[e];
}

/*
* function :	realize the calculation of sets by array
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
int addset(bool* sr, bool* s1, bool* s2, int n) {
	for (int i = 0; i<n; i++) {
		sr[i] = s1[i] || s2[i];
	}
	return 0;
}

/*
* function :	realize the calculation of sets by array
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
int subset(bool* sr, bool* s1, bool* s2, int n) {
	int i;
	for (i = 0; i<n; i++) {
		sr[i] = s1[i] && (!s2[i]);
	}
	return 0;
}

/*
* function :	realize the calculation of sets by array
* parameter :
* return :
* author :
* version :
* last change :
* notes :
*/
int mulset(bool* sr, bool* s1, bool* s2, int n) {
	int i;
	for (i = 0; i<n; i++) {
		sr[i] = s1[i] && s2[i];
	}
	return 0;
}
