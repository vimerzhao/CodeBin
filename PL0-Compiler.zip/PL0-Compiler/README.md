# PL/0 Compiler
PL/0 Language is a subset of Pascal with simple grammar,which is easy for learning and practising.

# How to use

```
gcc src/*.c
```

# Demo
with following code,input a number,you will get it's factorial until 0 is inputted

```
! input a number,you will get it's factorial until 0 is inputted
var a,ans,tmp;
procedure p;
 	begin
 		if a > 0 then begin
 			ans := ans * a;
 			a := a -1;
 			call p;
 		end;
 	end;
begin 
	tmp := 1;
	while tmp > 0 do begin
		ans := 1;
		read(a);
		tmp := a;
		call p;
		if tmp > 0 then write(ans);
	end;
end.
```

run:
![factorial](http://7y09c1.com1.z1.glb.clouddn.com/PL0demo.png)
# Plan

- [X] [Developer's Reference](https://github.com/zhaoyu1995/PL0-Compiler/blob/master/DOC/Reference.pdf)
- [X] [User's Manual](https://github.com/zhaoyu1995/PL0-Compiler/blob/master/DOC/User%20Manual%20of%20PL0.md)

# Reference
《编译原理》,清华大学出版社
