package vimerzhao.rssreader.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

import vimerzhao.rssreader.R
import vimerzhao.rssreader.model.PostBean


class PostListViewAdapter(private val postBeanList: List<PostBean>, context: Context) : BaseAdapter() {
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return postBeanList.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var convertView = convertView
        val viewHolder: ViewHolder
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_rss_post, null)
            viewHolder = ViewHolder()
            viewHolder.title = convertView!!.findViewById(R.id.post_title)
            viewHolder.description = convertView.findViewById(R.id.description)
            viewHolder.pubTime = convertView.findViewById(R.id.pub_time)
            viewHolder.source = convertView.findViewById(R.id.source)
            convertView.tag = viewHolder
        } else {
            viewHolder = convertView.tag as ViewHolder
        }
        viewHolder.title!!.text = postBeanList[position].title
        viewHolder.description!!.text = postBeanList[position].description
        viewHolder.pubTime?.text = postBeanList[position].pubTime
        viewHolder.source?.text = postBeanList[position].source
        return convertView
    }

    internal inner class ViewHolder {
        var title: TextView? = null
        var description: TextView? = null
        var pubTime: TextView? = null
        var source: TextView? = null
    }
}
