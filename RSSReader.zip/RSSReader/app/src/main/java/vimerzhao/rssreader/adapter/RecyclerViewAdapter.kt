package vimerzhao.rssreader.adapter


import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import vimerzhao.rssreader.R

class RecyclerViewAdapter(private val mWebsiteNameList: List<String>, context: Context) : RecyclerView.Adapter<RecyclerViewAdapter.ItemHolder>(), View.OnClickListener {
    var listener: OnItemClickListener? = null
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        val view = inflater.inflate(R.layout.item_rss_website, parent, false)
        val holder = ItemHolder(view)
        view.setOnClickListener(this)
        return holder
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {
        holder.websiteNameView.text = mWebsiteNameList[position]
        holder.itemView.tag = position
    }

    override fun getItemCount(): Int {
        return mWebsiteNameList.size
    }

    override fun onClick(v: View) {
        listener?.onItemClick(v, v.tag as Int)

    }

    inner class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var websiteNameView: TextView = itemView.findViewById(R.id.website_name)

    }

    interface OnItemClickListener {
        fun onItemClick(view: View, position: Int)
    }

}
