package vimerzhao.rssreader.model

open class RssSource {

    var theme: String? = null
    var author: String? = null
    var email: String? = null
    var version: String? = null
    var contents: List<ContentsBean>? = null

    class ContentsBean {

        var category: String? = null
        var websites: List<WebsitesBean>? = null

        class WebsitesBean {
            var tag: String? = null
            var url: List<String>? = null
        }
    }
}
