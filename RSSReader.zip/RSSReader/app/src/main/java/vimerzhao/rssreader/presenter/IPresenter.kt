package vimerzhao.rssreader.presenter

import vimerzhao.rssreader.model.RssSource


interface IPresenter {
    fun getRssResource(): RssSource
    fun onNavigationItemSelected(itemId: Int)
    fun updateList(url:ArrayList<String>)
}
