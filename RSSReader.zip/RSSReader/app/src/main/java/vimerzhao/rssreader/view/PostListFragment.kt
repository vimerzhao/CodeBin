package vimerzhao.rssreader.view

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import vimerzhao.rssreader.MainActivity
import vimerzhao.rssreader.R


class PostListFragment: Fragment() {
    lateinit var mRecyclerView: RecyclerView
    lateinit var postListView: ListView
    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val rootView = inflater?.inflate(R.layout.fragment_postlist, container, false)
        mRecyclerView = rootView!!.findViewById(R.id.website_recyclerview)
        postListView = rootView!!.findViewById(R.id.post_listview)
        (activity as MainActivity).setUI(mRecyclerView, postListView)
        return rootView
    }
}