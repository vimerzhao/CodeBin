package vimerzhao.rssreader.view

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.tencent.smtt.sdk.WebView
import com.tencent.smtt.sdk.WebViewClient
import vimerzhao.rssreader.MainActivity
import vimerzhao.rssreader.R


class PostviewFragment : Fragment() {

    private lateinit var webview:WebView
    private val client = object : WebViewClient() {
        // 防止加载网页时调起系统浏览器
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return true
        }
    }
    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val rootView = inflater!!.inflate(R.layout.fragment_postview, container, false)
        webview = rootView.findViewById(R.id.webview)
        webview.webViewClient = client
        return rootView
    }
    fun loadUrl() {
        val target = activity as MainActivity
        webview.loadUrl(target.postUrlList[target.clickPostion])
    }

    fun setBlank() {
        webview.loadUrl("about:blank")
    }

}