package vimerzhao.rssreader.presenter


import android.content.Context
import android.support.v4.view.GravityCompat
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import org.dom4j.DocumentHelper
import org.dom4j.Element
import org.jetbrains.anko.custom.async
import org.jetbrains.anko.uiThread
import vimerzhao.rssreader.MainActivity
import vimerzhao.rssreader.adapter.PostListViewAdapter
import vimerzhao.rssreader.adapter.RecyclerViewAdapter
import vimerzhao.rssreader.model.PostBean

import vimerzhao.rssreader.model.RssSource
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL


class PresenterImpl(val context: Context, val activity: MainActivity) : IPresenter {

    override fun getRssResource(): RssSource {
        val gson = GsonBuilder().create()
        return gson.fromJson(getFromAssets("RSS.json"), RssSource::class.java)
    }

    private fun getFromAssets(fileName: String): String {
        try {
            val inputReader = InputStreamReader(context.resources.assets.open(fileName))
            var result = StringBuilder()
            // Kotlin style
            BufferedReader(inputReader).use { r ->
                r.lineSequence().forEach{
                    result.append(it)
                }
            }

            return result.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }

    override fun onNavigationItemSelected(itemId: Int) {
        // Handle navigation view item clicks here.
        val list = ArrayList<String>()
        val urlList = ArrayList<String>()
        val urlSetList = ArrayList<ArrayList<String>>()

        for (i in activity.resource.contents!![itemId].websites!!) {
            list.add(i.tag!!)
            urlList += i.url!!
            urlSetList.add(i.url as ArrayList<String>)
        }

        updateList(urlSetList[0])
        val adapter = RecyclerViewAdapter(list, context)
        activity.mRecyclerView.adapter = adapter
        activity.drawer_layout.closeDrawer(GravityCompat.START)

        adapter.listener = object : RecyclerViewAdapter.OnItemClickListener {
            override fun onItemClick(view: View, position: Int) {
                updateList(urlSetList[position])
                Toast.makeText(context, urlSetList[position].toString(), Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun updateList(url:ArrayList<String>){
        activity.postUrlList.clear()
        async {
            val postList = ArrayList<PostBean>()
            for (link in url) {
                val res = URL(link).readText()

                val document = DocumentHelper.parseText(res)
                val list = document.selectNodes("//item")
                val source = document.selectSingleNode("//channel/title")
                println(list.size)
                list.forEach {
                    if (it is Element) {
                        val elementIterator = it.elementIterator()
                        val postBean = PostBean()
                        while (elementIterator.hasNext()) {
                            val element = elementIterator.next() as Element
                            when (element.name) {
                                "title" -> postBean.title = element.stringValue
                                "pubDate" -> postBean.pubTime = "更新时间: " + element.stringValue
                                "description" -> postBean.description = element.stringValue
                                "link" -> {
                                    postBean.url = element.stringValue
                                    activity.postUrlList.add(element.stringValue)
                                }

                            }
                        }
                        postBean.source = "来源: " + source.stringValue
                        postList.add(postBean)
                    }
                }
            }
            uiThread {
                activity.postListView.adapter = PostListViewAdapter(postList, activity.applicationContext)
                activity.postListView.invalidate()
            }
        }
    }
}
