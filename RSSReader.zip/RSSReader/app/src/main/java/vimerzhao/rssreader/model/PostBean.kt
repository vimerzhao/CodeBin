package vimerzhao.rssreader.model


class PostBean {
    var title: String = "unknown"
    var description: String = "unknown"
    var source: String = "unknown"
    var pubTime: String = "unknown"
    var url:String = "unknown"
}
