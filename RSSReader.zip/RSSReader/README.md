# RSSReader
Android RSS reader for coder

# TO-Do List

- [ ] 使用Fragment代替Activity
- [ ] 条目列表
- [ ] XML解析
- [ ] 阅读器优化
- [ ] 设定RSS源，实时更新
- [ ] 本地导入RSS源
- [ ] 机器/深度学习
- [ ] 日志模块
- [ ] 单元测试
- [ ] 社会化分享

