package crazyit;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        ViewerFrame f = new ViewerFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
